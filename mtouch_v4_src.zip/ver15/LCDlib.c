//
// LCD �\�����C�u�����p
//	10/02/15 ������Ѓr�b�g�E�g���[�h�E����
//
//  �s���z�u�͈ȉ��̒ʂ�
//		4:RS	RC7
//		5:R/W	GND
//		6:E		RC6
//		11:DB4	RB4
//		12:DB5	RB5
//		13:DB6	RB6
//		14:DB7	RB7
#include <p18f14k50.h>
#include <delays.h>

#define LCD_DATA	LATB
#define LCD_E		LATCbits.LATC6
#define LCD_RW 		NC
#define LCD_RS		LATCbits.LATC7
#define NOP		_asm NOP	_endasm

//������g���ɍ��킹�ĕύX
//�����ł́A8Mhz
void delay_us(int usec)
{
	while(usec)
	{
		NOP;
		NOP;
		usec--;
	}
}
void delay_ms(int msec)
{
	Delay1KTCYx(msec*2);
}

void lcd_out(char code, char flag)
{
	LCD_DATA = (code & 0x0F)<<4;

	LCD_RS = (flag == 0) ? 1 : 0;

	delay_us(1);
	LCD_E = 1;
	delay_us(1);
	LCD_E = 0;
}

void lcd_data(char asci)
{
	lcd_out((asci>>4), 0);
	lcd_out((asci),0);
	delay_us(50);
}

void lcd_cmd(char cmd)
{
	lcd_out((cmd>>4),1);
	lcd_out((cmd),1);
	if((cmd & 0x03) != 0)
		delay_ms(2);
	else
		delay_us(50);
}

void lcd_init(void)
{
	delay_ms(20);
	lcd_out(0x3, 1);
	delay_ms(5);
	lcd_out(0x3,1);
	delay_ms(1);
	lcd_out(0x3,1);
	delay_ms(1);
	lcd_out(0x2,1);
	delay_ms(1);
	lcd_cmd(0x2e);
	lcd_cmd(0x08);
	lcd_cmd(0x0d);
	lcd_cmd(0x06);
	lcd_cmd(0x02);
}

void lcd_clear(void)
{
	lcd_cmd(0x01);
	delay_ms(17);
}

void lcd_disp(unsigned char DCB)
{
	lcd_cmd(0x08 | DCB);
	delay_us(50);
}

void lcd_str(char *str)
{
	while(*str != 0x00)
	{
		lcd_data(*str);
		str++;
	}
}

void lcd_home(void)
{
	lcd_cmd(0x02);
	delay_ms(17);
}

void lcd_num(unsigned int num,char keta)
{
	int fi;
	int disp_num;
	int keta_sub = 1;

	for(fi = 0;fi < (keta-1);fi++)
		keta_sub *= 10;

	while(keta != 0)
	{
		keta--;
		disp_num = (num / keta_sub);
		lcd_data(disp_num + 0x30);
		num = num % keta_sub;
		keta_sub /= 10;
	}
}

void lcd_move(char x,char y)
{
	lcd_cmd(0x80 | (y==1 ? 0x40 : 0) | x);
	delay_us(50);
}